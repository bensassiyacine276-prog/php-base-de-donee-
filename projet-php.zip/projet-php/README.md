# Projet PHP - Affichage base de données

## Installation

1. Cloner le dépôt :
   ```bash
   git clone https://github.com/votre-repo/projet-php.git
   ```

2. Copier le fichier d'exemple des credentials :
   ```bash
   cp credentials.example.php credentials.php
   ```

3. Modifier `credentials.php` avec vos propres identifiants de base de données.

4. Adapter le nom de la table dans `index.php` (remplacer `ma_table`).

5. Lancer le projet via PhpStorm ou un serveur local (WAMP, XAMPP, MAMP).

## Structure du projet

```
projet-php/
├── .gitignore                  # Ignore credentials.php
├── credentials.example.php     # Modèle de configuration (versionné)
├── credentials.php             # Vos identifiants locaux (NON versionné)
├── index.php                   # Page principale - SELECT + affichage
└── README.md
```

## Remarques

- `credentials.php` n'est **jamais** poussé sur GitHub (ignoré via `.gitignore`)
- Chaque membre du groupe doit créer son propre `credentials.php` localement
